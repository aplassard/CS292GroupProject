(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages\loading\client\lib\spin.js                                                                          //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
/**                                                                                                             // 1
 * Version 1.3.3 (24.12.2013)                                                                                   // 2
 * Copyright (c) 2011-2013 Felix Gnass                                                                          // 3
 * Licensed under the MIT license                                                                               // 4
 */                                                                                                             // 5
(function(root, factory) {                                                                                      // 6
                                                                                                                // 7
  /* CommonJS */                                                                                                // 8
  if (typeof exports == 'object')  module.exports = factory()                                                   // 9
                                                                                                                // 10
  /* AMD module */                                                                                              // 11
  else if (typeof define == 'function' && define.amd) define(factory)                                           // 12
                                                                                                                // 13
  /* Browser global */                                                                                          // 14
  else root.Spinner = factory()                                                                                 // 15
}                                                                                                               // 16
(this, function() {                                                                                             // 17
  "use strict";                                                                                                 // 18
                                                                                                                // 19
  var prefixes = ['webkit', 'Moz', 'ms', 'O'] /* Vendor prefixes */                                             // 20
    , animations = {} /* Animation rules keyed by their name */                                                 // 21
    , useCssAnimations /* Whether to use CSS animations or setTimeout */                                        // 22
                                                                                                                // 23
  /**                                                                                                           // 24
   * Utility function to create elements. If no tag name is given,                                              // 25
   * a DIV is created. Optionally properties can be passed.                                                     // 26
   */                                                                                                           // 27
  function createEl(tag, prop) {                                                                                // 28
    var el = document.createElement(tag || 'div')                                                               // 29
      , n                                                                                                       // 30
                                                                                                                // 31
    for(n in prop) el[n] = prop[n]                                                                              // 32
    return el                                                                                                   // 33
  }                                                                                                             // 34
                                                                                                                // 35
  /**                                                                                                           // 36
   * Appends children and returns the parent.                                                                   // 37
   */                                                                                                           // 38
  function ins(parent /* child1, child2, ...*/) {                                                               // 39
    for (var i=1, n=arguments.length; i<n; i++)                                                                 // 40
      parent.appendChild(arguments[i])                                                                          // 41
                                                                                                                // 42
    return parent                                                                                               // 43
  }                                                                                                             // 44
                                                                                                                // 45
  /**                                                                                                           // 46
   * Insert a new stylesheet to hold the @keyframe or VML rules.                                                // 47
   */                                                                                                           // 48
  var sheet = (function() {                                                                                     // 49
    var el = createEl('style', {type : 'text/css'})                                                             // 50
    ins(document.getElementsByTagName('head')[0], el)                                                           // 51
    return el.sheet || el.styleSheet                                                                            // 52
  }())                                                                                                          // 53
                                                                                                                // 54
  /**                                                                                                           // 55
   * Creates an opacity keyframe animation rule and returns its name.                                           // 56
   * Since most mobile Webkits have timing issues with animation-delay,                                         // 57
   * we create separate rules for each line/segment.                                                            // 58
   */                                                                                                           // 59
  function addAnimation(alpha, trail, i, lines) {                                                               // 60
    var name = ['opacity', trail, ~~(alpha*100), i, lines].join('-')                                            // 61
      , start = 0.01 + i/lines * 100                                                                            // 62
      , z = Math.max(1 - (1-alpha) / trail * (100-start), alpha)                                                // 63
      , prefix = useCssAnimations.substring(0, useCssAnimations.indexOf('Animation')).toLowerCase()             // 64
      , pre = prefix && '-' + prefix + '-' || ''                                                                // 65
                                                                                                                // 66
    if (!animations[name]) {                                                                                    // 67
      sheet.insertRule(                                                                                         // 68
        '@' + pre + 'keyframes ' + name + '{' +                                                                 // 69
        '0%{opacity:' + z + '}' +                                                                               // 70
        start + '%{opacity:' + alpha + '}' +                                                                    // 71
        (start+0.01) + '%{opacity:1}' +                                                                         // 72
        (start+trail) % 100 + '%{opacity:' + alpha + '}' +                                                      // 73
        '100%{opacity:' + z + '}' +                                                                             // 74
        '}', sheet.cssRules.length)                                                                             // 75
                                                                                                                // 76
      animations[name] = 1                                                                                      // 77
    }                                                                                                           // 78
                                                                                                                // 79
    return name                                                                                                 // 80
  }                                                                                                             // 81
                                                                                                                // 82
  /**                                                                                                           // 83
   * Tries various vendor prefixes and returns the first supported property.                                    // 84
   */                                                                                                           // 85
  function vendor(el, prop) {                                                                                   // 86
    var s = el.style                                                                                            // 87
      , pp                                                                                                      // 88
      , i                                                                                                       // 89
                                                                                                                // 90
    prop = prop.charAt(0).toUpperCase() + prop.slice(1)                                                         // 91
    for(i=0; i<prefixes.length; i++) {                                                                          // 92
      pp = prefixes[i]+prop                                                                                     // 93
      if(s[pp] !== undefined) return pp                                                                         // 94
    }                                                                                                           // 95
    if(s[prop] !== undefined) return prop                                                                       // 96
  }                                                                                                             // 97
                                                                                                                // 98
  /**                                                                                                           // 99
   * Sets multiple style properties at once.                                                                    // 100
   */                                                                                                           // 101
  function css(el, prop) {                                                                                      // 102
    for (var n in prop)                                                                                         // 103
      el.style[vendor(el, n)||n] = prop[n]                                                                      // 104
                                                                                                                // 105
    return el                                                                                                   // 106
  }                                                                                                             // 107
                                                                                                                // 108
  /**                                                                                                           // 109
   * Fills in default values.                                                                                   // 110
   */                                                                                                           // 111
  function merge(obj) {                                                                                         // 112
    for (var i=1; i < arguments.length; i++) {                                                                  // 113
      var def = arguments[i]                                                                                    // 114
      for (var n in def)                                                                                        // 115
        if (obj[n] === undefined) obj[n] = def[n]                                                               // 116
    }                                                                                                           // 117
    return obj                                                                                                  // 118
  }                                                                                                             // 119
                                                                                                                // 120
  /**                                                                                                           // 121
   * Returns the absolute page-offset of the given element.                                                     // 122
   */                                                                                                           // 123
  function pos(el) {                                                                                            // 124
    var o = { x:el.offsetLeft, y:el.offsetTop }                                                                 // 125
    while((el = el.offsetParent))                                                                               // 126
      o.x+=el.offsetLeft, o.y+=el.offsetTop                                                                     // 127
                                                                                                                // 128
    return o                                                                                                    // 129
  }                                                                                                             // 130
                                                                                                                // 131
  /**                                                                                                           // 132
   * Returns the line color from the given string or array.                                                     // 133
   */                                                                                                           // 134
  function getColor(color, idx) {                                                                               // 135
    return typeof color == 'string' ? color : color[idx % color.length]                                         // 136
  }                                                                                                             // 137
                                                                                                                // 138
  // Built-in defaults                                                                                          // 139
                                                                                                                // 140
  var defaults = {                                                                                              // 141
    lines: 12,            // The number of lines to draw                                                        // 142
    length: 7,            // The length of each line                                                            // 143
    width: 5,             // The line thickness                                                                 // 144
    radius: 10,           // The radius of the inner circle                                                     // 145
    rotate: 0,            // Rotation offset                                                                    // 146
    corners: 1,           // Roundness (0..1)                                                                   // 147
    color: '#000',        // #rgb or #rrggbb                                                                    // 148
    direction: 1,         // 1: clockwise, -1: counterclockwise                                                 // 149
    speed: 1,             // Rounds per second                                                                  // 150
    trail: 100,           // Afterglow percentage                                                               // 151
    opacity: 1/4,         // Opacity of the lines                                                               // 152
    fps: 20,              // Frames per second when using setTimeout()                                          // 153
    zIndex: 2e9,          // Use a high z-index by default                                                      // 154
    className: 'spinner', // CSS class to assign to the element                                                 // 155
    top: 'auto',          // center vertically                                                                  // 156
    left: 'auto',         // center horizontally                                                                // 157
    position: 'relative'  // element position                                                                   // 158
  }                                                                                                             // 159
                                                                                                                // 160
  /** The constructor */                                                                                        // 161
  function Spinner(o) {                                                                                         // 162
    if (typeof this == 'undefined') return new Spinner(o)                                                       // 163
    this.opts = merge(o || {}, Spinner.defaults, defaults)                                                      // 164
  }                                                                                                             // 165
                                                                                                                // 166
  // Global defaults that override the built-ins:                                                               // 167
  Spinner.defaults = {}                                                                                         // 168
                                                                                                                // 169
  merge(Spinner.prototype, {                                                                                    // 170
                                                                                                                // 171
    /**                                                                                                         // 172
     * Adds the spinner to the given target element. If this instance is already                                // 173
     * spinning, it is automatically removed from its previous target b calling                                 // 174
     * stop() internally.                                                                                       // 175
     */                                                                                                         // 176
    spin: function(target) {                                                                                    // 177
      this.stop()                                                                                               // 178
                                                                                                                // 179
      var self = this                                                                                           // 180
        , o = self.opts                                                                                         // 181
        , el = self.el = css(createEl(0, {className: o.className}), {position: o.position, width: 0, zIndex: o.zIndex})
        , mid = o.radius+o.length+o.width                                                                       // 183
        , ep // element position                                                                                // 184
        , tp // target position                                                                                 // 185
                                                                                                                // 186
      if (target) {                                                                                             // 187
        target.insertBefore(el, target.firstChild||null)                                                        // 188
        tp = pos(target)                                                                                        // 189
        ep = pos(el)                                                                                            // 190
        css(el, {                                                                                               // 191
          left: (o.left == 'auto' ? tp.x-ep.x + (target.offsetWidth >> 1) : parseInt(o.left, 10) + mid) + 'px', // 192
          top: (o.top == 'auto' ? tp.y-ep.y + (target.offsetHeight >> 1) : parseInt(o.top, 10) + mid)  + 'px'   // 193
        })                                                                                                      // 194
      }                                                                                                         // 195
                                                                                                                // 196
      el.setAttribute('role', 'progressbar')                                                                    // 197
      self.lines(el, self.opts)                                                                                 // 198
                                                                                                                // 199
      if (!useCssAnimations) {                                                                                  // 200
        // No CSS animation support, use setTimeout() instead                                                   // 201
        var i = 0                                                                                               // 202
          , start = (o.lines - 1) * (1 - o.direction) / 2                                                       // 203
          , alpha                                                                                               // 204
          , fps = o.fps                                                                                         // 205
          , f = fps/o.speed                                                                                     // 206
          , ostep = (1-o.opacity) / (f*o.trail / 100)                                                           // 207
          , astep = f/o.lines                                                                                   // 208
                                                                                                                // 209
        ;(function anim() {                                                                                     // 210
          i++;                                                                                                  // 211
          for (var j = 0; j < o.lines; j++) {                                                                   // 212
            alpha = Math.max(1 - (i + (o.lines - j) * astep) % f * ostep, o.opacity)                            // 213
                                                                                                                // 214
            self.opacity(el, j * o.direction + start, alpha, o)                                                 // 215
          }                                                                                                     // 216
          self.timeout = self.el && setTimeout(anim, ~~(1000/fps))                                              // 217
        })()                                                                                                    // 218
      }                                                                                                         // 219
      return self                                                                                               // 220
    },                                                                                                          // 221
                                                                                                                // 222
    /**                                                                                                         // 223
     * Stops and removes the Spinner.                                                                           // 224
     */                                                                                                         // 225
    stop: function() {                                                                                          // 226
      var el = this.el                                                                                          // 227
      if (el) {                                                                                                 // 228
        clearTimeout(this.timeout)                                                                              // 229
        if (el.parentNode) el.parentNode.removeChild(el)                                                        // 230
        this.el = undefined                                                                                     // 231
      }                                                                                                         // 232
      return this                                                                                               // 233
    },                                                                                                          // 234
                                                                                                                // 235
    /**                                                                                                         // 236
     * Internal method that draws the individual lines. Will be overwritten                                     // 237
     * in VML fallback mode below.                                                                              // 238
     */                                                                                                         // 239
    lines: function(el, o) {                                                                                    // 240
      var i = 0                                                                                                 // 241
        , start = (o.lines - 1) * (1 - o.direction) / 2                                                         // 242
        , seg                                                                                                   // 243
                                                                                                                // 244
      function fill(color, shadow) {                                                                            // 245
        return css(createEl(), {                                                                                // 246
          position: 'absolute',                                                                                 // 247
          width: (o.length+o.width) + 'px',                                                                     // 248
          height: o.width + 'px',                                                                               // 249
          background: color,                                                                                    // 250
          boxShadow: shadow,                                                                                    // 251
          transformOrigin: 'left',                                                                              // 252
          transform: 'rotate(' + ~~(360/o.lines*i+o.rotate) + 'deg) translate(' + o.radius+'px' +',0)',         // 253
          borderRadius: (o.corners * o.width>>1) + 'px'                                                         // 254
        })                                                                                                      // 255
      }                                                                                                         // 256
                                                                                                                // 257
      for (; i < o.lines; i++) {                                                                                // 258
        seg = css(createEl(), {                                                                                 // 259
          position: 'absolute',                                                                                 // 260
          top: 1+~(o.width/2) + 'px',                                                                           // 261
          transform: o.hwaccel ? 'translate3d(0,0,0)' : '',                                                     // 262
          opacity: o.opacity,                                                                                   // 263
          animation: useCssAnimations && addAnimation(o.opacity, o.trail, start + i * o.direction, o.lines) + ' ' + 1/o.speed + 's linear infinite'
        })                                                                                                      // 265
                                                                                                                // 266
        if (o.shadow) ins(seg, css(fill('#000', '0 0 4px ' + '#000'), {top: 2+'px'}))                           // 267
        ins(el, ins(seg, fill(getColor(o.color, i), '0 0 1px rgba(0,0,0,.1)')))                                 // 268
      }                                                                                                         // 269
      return el                                                                                                 // 270
    },                                                                                                          // 271
                                                                                                                // 272
    /**                                                                                                         // 273
     * Internal method that adjusts the opacity of a single line.                                               // 274
     * Will be overwritten in VML fallback mode below.                                                          // 275
     */                                                                                                         // 276
    opacity: function(el, i, val) {                                                                             // 277
      if (i < el.childNodes.length) el.childNodes[i].style.opacity = val                                        // 278
    }                                                                                                           // 279
                                                                                                                // 280
  })                                                                                                            // 281
                                                                                                                // 282
                                                                                                                // 283
  function initVML() {                                                                                          // 284
                                                                                                                // 285
    /* Utility function to create a VML tag */                                                                  // 286
    function vml(tag, attr) {                                                                                   // 287
      return createEl('<' + tag + ' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">', attr)             // 288
    }                                                                                                           // 289
                                                                                                                // 290
    // No CSS transforms but VML support, add a CSS rule for VML elements:                                      // 291
    sheet.addRule('.spin-vml', 'behavior:url(#default#VML)')                                                    // 292
                                                                                                                // 293
    Spinner.prototype.lines = function(el, o) {                                                                 // 294
      var r = o.length+o.width                                                                                  // 295
        , s = 2*r                                                                                               // 296
                                                                                                                // 297
      function grp() {                                                                                          // 298
        return css(                                                                                             // 299
          vml('group', {                                                                                        // 300
            coordsize: s + ' ' + s,                                                                             // 301
            coordorigin: -r + ' ' + -r                                                                          // 302
          }),                                                                                                   // 303
          { width: s, height: s }                                                                               // 304
        )                                                                                                       // 305
      }                                                                                                         // 306
                                                                                                                // 307
      var margin = -(o.width+o.length)*2 + 'px'                                                                 // 308
        , g = css(grp(), {position: 'absolute', top: margin, left: margin})                                     // 309
        , i                                                                                                     // 310
                                                                                                                // 311
      function seg(i, dx, filter) {                                                                             // 312
        ins(g,                                                                                                  // 313
          ins(css(grp(), {rotation: 360 / o.lines * i + 'deg', left: ~~dx}),                                    // 314
            ins(css(vml('roundrect', {arcsize: o.corners}), {                                                   // 315
                width: r,                                                                                       // 316
                height: o.width,                                                                                // 317
                left: o.radius,                                                                                 // 318
                top: -o.width>>1,                                                                               // 319
                filter: filter                                                                                  // 320
              }),                                                                                               // 321
              vml('fill', {color: getColor(o.color, i), opacity: o.opacity}),                                   // 322
              vml('stroke', {opacity: 0}) // transparent stroke to fix color bleeding upon opacity change       // 323
            )                                                                                                   // 324
          )                                                                                                     // 325
        )                                                                                                       // 326
      }                                                                                                         // 327
                                                                                                                // 328
      if (o.shadow)                                                                                             // 329
        for (i = 1; i <= o.lines; i++)                                                                          // 330
          seg(i, -2, 'progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)')     // 331
                                                                                                                // 332
      for (i = 1; i <= o.lines; i++) seg(i)                                                                     // 333
      return ins(el, g)                                                                                         // 334
    }                                                                                                           // 335
                                                                                                                // 336
    Spinner.prototype.opacity = function(el, i, val, o) {                                                       // 337
      var c = el.firstChild                                                                                     // 338
      o = o.shadow && o.lines || 0                                                                              // 339
      if (c && i+o < c.childNodes.length) {                                                                     // 340
        c = c.childNodes[i+o]; c = c && c.firstChild; c = c && c.firstChild                                     // 341
        if (c) c.opacity = val                                                                                  // 342
      }                                                                                                         // 343
    }                                                                                                           // 344
  }                                                                                                             // 345
                                                                                                                // 346
  var probe = css(createEl('group'), {behavior: 'url(#default#VML)'})                                           // 347
                                                                                                                // 348
  if (!vendor(probe, 'transform') && probe.adj) initVML()                                                       // 349
  else useCssAnimations = vendor(probe, 'animation')                                                            // 350
                                                                                                                // 351
  return Spinner                                                                                                // 352
                                                                                                                // 353
}));                                                                                                            // 354
                                                                                                                // 355
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages\loading\client\template.loading.js                                                                  //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
                                                                                                                // 1
Template.__define__("loading", (function() {                                                                    // 2
  var self = this;                                                                                              // 3
  var template = this;                                                                                          // 4
  return HTML.Raw('<div id="loading" class="loading"></div>');                                                  // 5
}));                                                                                                            // 6
                                                                                                                // 7
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);






(function () {

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                              //
// packages\loading\client\loading.js                                                                           //
//                                                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                //
LoadingOverlay = {                                                                                              // 1
  spinnerJsDefaultOpts : {                                                                                      // 2
    lines: 11,      // The number of lines to draw                                                              // 3
    length: 15,     // The length of each line                                                                  // 4
    width: 15,      // The line thickness                                                                       // 5
    radius: 10,     // The radius of the inner circle                                                           // 6
    corners: 1,     // Corner roundness (0..1)                                                                  // 7
    rotate: 0,      // The rotation offset                                                                      // 8
    direction: 1,   // 1: clockwise, -1: counterclockwise                                                       // 9
    color: '#fff',  // #rgb or #rrggbb or array of colors                                                       // 10
    speed: 2,       // Rounds per second                                                                        // 11
    trail: 50,      // Afterglow percentage                                                                     // 12
    shadow: true,   // Whether to render a shadow                                                               // 13
    hwaccel: false, // Whether to use hardware acceleration                                                     // 14
    className: 'spinner', // The CSS class to assign to the spinner                                             // 15
    zIndex: 2e9,    // The z-index (defaults to 2000000000)                                                     // 16
    top: 'auto',    // Top position relative to parent in px                                                    // 17
    left: 'auto'    // Left position relative to parent in px                                                   // 18
  },                                                                                                            // 19
                                                                                                                // 20
  createNewSpinner : function(selector, spinnerOpts) {                                                          // 21
    selector = selector || 'loading';                                                                           // 22
    return new Spinner(spinnerOpts || this.spinnerJsDefaultOpts).spin(                                          // 23
      document.getElementById( selector ) );                                                                    // 24
  },                                                                                                            // 25
                                                                                                                // 26
  createLoadingOverlay : function(target, overlayColor) {                                                       // 27
    target = target || 'body';                                                                                  // 28
    var $overlay = $('#loading');                                                                               // 29
                                                                                                                // 30
    if ( $overlay.length > 0 ) {                                                                                // 31
      $overlay.remove();                                                                                        // 32
    }                                                                                                           // 33
                                                                                                                // 34
    $overlay = $('<div id="loading" class="loading"></div>');                                                   // 35
    $( target ).append( $overlay );                                                                             // 36
                                                                                                                // 37
    if ( overlayColor )                                                                                         // 38
      $overlay.css( 'background-color', overlayColor);                                                          // 39
                                                                                                                // 40
    this.createNewSpinner( 'loading' );                                                                         // 41
  },                                                                                                            // 42
                                                                                                                // 43
  destroyLoadingOverlay : function( selector ) {                                                                // 44
    var $overlay = $( selector || '#loading' )                                                                  // 45
    if ( $overlay.length > 0 )                                                                                  // 46
      $.each($overlay, function(index, obj) {                                                                   // 47
        $(obj).addClass('animated fadeOut');                                                                    // 48
        setTimeout(function() { obj.remove(); }, 500);                                                          // 49
      });                                                                                                       // 50
  }                                                                                                             // 51
}                                                                                                               // 52
                                                                                                                // 53
// TEMPLATE HANDLING                                                                                            // 54
// -----------------------------------------------------------------------------                                // 55
Template.loading.rendered = function () {                                                                       // 56
  LoadingOverlay.createLoadingOverlay();                                                                        // 57
};                                                                                                              // 58
Template.loading.destroyed = function () {                                                                      // 59
  LoadingOverlay.destroyLoadingOverlay();                                                                       // 60
};                                                                                                              // 61
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);
