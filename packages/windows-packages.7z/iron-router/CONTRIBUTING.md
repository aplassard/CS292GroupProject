Please see https://github.com/EventedMind/iron-router#filing-issues-and-contributing for information about contributing.
