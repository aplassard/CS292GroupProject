Meteor Bootstrap-3
==================

[Bootstrap 3.x](http://getbootstrap.com) packaged for [Meteor](http://meteor.com).


### Installation

With [Meteorite](https://github.com/oortcloud/meteorite) installed:

```sh
$ mrt add bootstrap-3
```
